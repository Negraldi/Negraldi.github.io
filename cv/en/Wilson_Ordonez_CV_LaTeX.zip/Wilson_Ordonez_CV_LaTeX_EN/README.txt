RÉSUMÉ — WILSON ABDÓN ORDÓÑEZ RAMOS (LaTeX source, English)

Compile with XeLaTeX, two passes, from this folder:
  xelatex Wilson_Ordonez_Resume_2p.tex
  xelatex Wilson_Ordonez_CV_full.tex
On Overleaf: upload the whole folder and choose the XeLaTeX compiler.

estilo.tex   shared typographic system ("spec sheet")
fonts/       IBM Plex Sans and IBM Plex Mono (SIL Open Font License)
qr/          QR code to the website, placed in the header
Spanish version: https://negraldi.github.io/
