CV — WILSON ABDÓN ORDÓÑEZ RAMOS (fuente LaTeX, español)

Compilar con XeLaTeX, dos pasadas, desde esta carpeta:
  xelatex Wilson_Ordonez_CV_2p.tex
  xelatex Wilson_Ordonez_CV_completo.tex
En Overleaf: subir la carpeta completa y elegir el compilador XeLaTeX.

estilo.tex   sistema tipográfico compartido ("ficha técnica")
fonts/       IBM Plex Sans y IBM Plex Mono (SIL Open Font License)
qr/          QR a la web que va en el encabezado
Versión en inglés: https://negraldi.github.io/en/
