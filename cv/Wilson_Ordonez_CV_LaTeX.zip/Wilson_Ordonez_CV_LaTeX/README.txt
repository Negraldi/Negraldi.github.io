CV — WILSON ABDÓN ORDÓÑEZ RAMOS (fuente LaTeX)

Compilar con XeLaTeX, dos pasadas, desde esta carpeta:
  xelatex Wilson_Ordonez_CV_2p.tex
  xelatex Wilson_Ordonez_CV_completo.tex
En Overleaf: subir la carpeta completa y elegir el compilador XeLaTeX.

estilo.tex   sistema tipográfico compartido ("ficha técnica")
fonts/       IBM Plex Sans y IBM Plex Mono (SIL Open Font License)
qr/          QR a https://negraldi.github.io/ que va en el encabezado

Sin la carpeta fonts/ el documento usa TeX Gyre Heros y Latin Modern Mono.
Web: https://negraldi.github.io/
