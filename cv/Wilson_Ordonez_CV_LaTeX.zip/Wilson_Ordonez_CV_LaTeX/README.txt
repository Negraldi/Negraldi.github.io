CV — WILSON ABDÓN ORDÓÑEZ RAMOS · rediseño octubre 2026

ARCHIVOS
  Wilson_Ordonez_CV_2p.tex / .pdf        Versión para postular (2 páginas, referencias a solicitud)
  Wilson_Ordonez_CV_completo.tex / .pdf  Versión completa (4 páginas, con cursos y referencias)
  estilo.tex                             Sistema tipográfico compartido por ambas versiones
  fonts/                                 Source Serif 4 y Source Sans 3 (SIL Open Font License)

COMPILAR
  xelatex Wilson_Ordonez_CV_2p.tex   (dos pasadas; igual para la versión completa)
  Overleaf: subir todo el paquete y elegir el compilador XeLaTeX.

